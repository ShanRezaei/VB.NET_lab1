﻿Module Module2
    Sub Main(args As String())

        Dim firstnum, secondnum, answer As Integer
        Dim ops As String
        Dim EX As Integer






        Do

            Console.WriteLine("Enter first number" + vbNewLine)
            firstnum = Console.ReadLine()
            If IsNumeric(firstnum) = True Then

                Console.WriteLine("Enter second number" + vbNewLine)
                secondnum = Console.ReadLine()


                If IsNumeric(secondnum) = True Then


                    Console.WriteLine("select an operator:" + vbNewLine)
                    Console.WriteLine("A stands for addition" + vbNewLine)
                    Console.WriteLine("S stands for Substraction" + vbNewLine)
                    Console.WriteLine("M stands for Multiplication" + vbNewLine)
                    Console.WriteLine("MOD stands for Modulo" + vbNewLine)
                    Console.WriteLine("D stands for Division" + vbNewLine)

                    ops = Console.ReadLine()




                    If (ops = "A") Then
                        answer = firstnum + secondnum
                    ElseIf (ops = "S") Then
                        answer = firstnum - secondnum
                    ElseIf (ops = "M") Then
                        answer = firstnum * secondnum
                    ElseIf (ops = "POW") Then
                        answer = firstnum ^ secondnum
                    ElseIf (ops = "MOD") Then
                        answer = firstnum Mod secondnum
                    ElseIf (ops = "D") Then
                        answer = firstnum / secondnum


                    Else
                        Console.WriteLine("NOT A VALID OPERATOR" + vbNewLine)
                        Console.ReadKey()

                    End If
                    Console.Write("The answer is:" & firstnum & " " & ops & " " & secondnum & "=" & answer)
                    Console.ReadLine()
                Else
                    Console.WriteLine("NOT A VALID entry" + vbNewLine)
                    Console.ReadKey()
                End If
            Else
                Console.WriteLine("NOT A VALID entry" + vbNewLine)
                Console.ReadKey()
            End If





            Console.WriteLine("IF YOU SELECT 0 YOU CAN EXIT BUT IF 1 you can do your calculation" + vbNewLine)
            EX = Console.ReadLine()

        Loop While EX = 1

        Console.WriteLine("GOODBYE" + vbNewLine)
        Console.ReadLine()
    End Sub


End Module
