﻿Module Module4
    Sub Main(args As String())
        Dim i, z, j, m As Integer

        Console.Write("enter the  number:")
        z = Console.ReadLine()


        For i = 0 To z / 2
            Console.Write(Space(z / 2 - i))

            For j = 0 To (i)
                Console.Write("*")
                m = m + 1
                If m = z Then
                    Exit For
                End If

            Next j
            Console.WriteLine()
            If m = z Then
                Exit For
            End If
        Next i
        Console.ReadLine()
    End Sub
End Module
