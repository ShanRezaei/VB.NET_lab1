﻿Module Module3
    Sub Main(args As String())

        Dim index As Integer
        Dim total As String
        Dim quantity As Integer
        Dim choose As Integer
        Dim grand_total As Integer = 0



        Do

            Console.WriteLine("select your item:" + vbNewLine)
            Console.WriteLine("1 for item 1 : 10.99" + vbNewLine)
            Console.WriteLine("2 for item 2 : 5.66" + vbNewLine)
            Console.WriteLine("3 for item 3 : 7.65" + vbNewLine)
            Console.WriteLine("4 for item 4 : 8.64" + vbNewLine)
            Console.WriteLine("5 for item 5 : 5.00" + vbNewLine)
            Console.WriteLine("6 for item 6 : 7.20" + vbNewLine)
            Console.WriteLine("7 for item 7 : 10.00" + vbNewLine)
            choose = Console.ReadLine()



            Select Case choose
                Case 1
                    Console.WriteLine("select your quantity:" + vbNewLine)
                    quantity = Console.ReadLine()

                    If quantity > 15 Or quantity < 1 Then
                        Console.WriteLine("choosen quantity is wrong it should be between 1 to 15" + vbNewLine)
                        Console.ReadLine()

                    Else
                        total = quantity * 10.99
                        Console.WriteLine("your total :" & total + vbNewLine)
                        Console.ReadLine()

                    End If




                Case 2
                    Console.WriteLine("select your quantity:" + vbNewLine)
                    quantity = Console.ReadLine()

                    If quantity > 15 Or quantity < 1 Then
                        Console.WriteLine("choosen quantity is wrong it should be between 1 to 15" + vbNewLine)
                        Console.ReadLine()

                    Else
                        total = quantity * 5.66
                        Console.WriteLine("your total :" & total)
                        Console.ReadLine()

                    End If

                Case 3
                    Console.WriteLine("select your quantity:" + vbNewLine)
                    quantity = Console.ReadLine()

                    If quantity > 15 Or quantity < 1 Then
                        Console.WriteLine("choosen quantity is wrong it should be between 1 to 15" + vbNewLine)
                        Console.ReadLine()

                    Else
                        total = quantity * 7.65
                        Console.WriteLine("your total :" & total)
                        Console.ReadLine()

                    End If

                Case 4
                    Console.WriteLine("select your quantity:" + vbNewLine)
                    quantity = Console.ReadLine()

                    If quantity > 15 Or quantity < 1 Then
                        Console.WriteLine("choosen quantity is wrong it should be between 1 to 15" + vbNewLine)
                        Console.ReadLine()

                    Else
                        total = quantity * 8.64
                        Console.WriteLine("your total :" & total)
                        Console.ReadLine()

                    End If


                Case 5
                    Console.WriteLine("select your quantity:" + vbNewLine)
                    quantity = Console.ReadLine()

                    If quantity > 15 Or quantity < 1 Then
                        Console.WriteLine("choosen quantity is wrong it should be between 1 to 15" + vbNewLine)
                        Console.ReadLine()

                    Else
                        total = quantity * 5.0
                        Console.WriteLine("your total :" & total)
                        Console.ReadLine()

                    End If

                Case 6
                    Console.WriteLine("select your quantity:" + vbNewLine)
                    quantity = Console.ReadLine()

                    If quantity > 15 Or quantity < 1 Then
                        Console.WriteLine("choosen quantity is wrong it should be between 1 to 15" + vbNewLine)
                        Console.ReadLine()

                    Else
                        total = quantity * 7.2
                        Console.WriteLine("your total :" & total)
                        Console.ReadLine()

                    End If

                Case 7
                    Console.WriteLine("select your quantity:" + vbNewLine)
                    quantity = Console.ReadLine()

                    If quantity > 15 Or quantity < 1 Then
                        Console.WriteLine("choosen quantity is wrong it should be between 1 to 15" + vbNewLine)
                        Console.ReadLine()

                    Else
                        total = quantity * 10.0
                        Console.WriteLine("your total :" & total)
                        Console.ReadLine()

                    End If



                Case Else
                    Console.WriteLine("you have not entered the valid number for choosing the item")
                    Console.ReadLine()
            End Select

            grand_total = grand_total + total



            Console.WriteLine("if you would like to continue shopping press 1 " + vbNewLine)
            Console.WriteLine("if you would like to stop shopping press 0 " + vbNewLine)
            index = Console.ReadLine()



        Loop While index = 1


        Console.WriteLine("grand_total :" & grand_total)
        Console.ReadLine()
    End Sub
End Module
