﻿Module Module1
    Sub Main(args As String())

        Dim number1 As Integer
        Dim number2 As Integer
        Dim number3 As Integer
        Dim total As Integer
        Dim Avg As Integer

        Console.Write("enter the first number:")
        number1 = Convert.ToInt32(Console.ReadLine())


        Console.Write("enter the second number:")
        number2 = Convert.ToInt32(Console.ReadLine())

        Console.Write("enter the third number:")
        number3 = Convert.ToInt32(Console.ReadLine())

        If IsNumeric(number1 And number2 And number3) Then
            total = (number1 + number2 + number3)
            Avg = (number1 + number2 + number3) / 3

            Console.WriteLine("the total is:" & total)
            Console.WriteLine("the Avg is:" & Avg)


        Else
            Console.WriteLine("the invalid input")

        End If



        Console.ReadLine()

    End Sub
End Module
